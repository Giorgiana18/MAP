import pyautogui
import time
import keyboard

def cautare_google():
    if pyautogui.locateOnScreen(r"C:\Imagini\search.png", confidence=0.7) != None:
        camp_google = pyautogui.locateOnScreen(r"C:\Imagini\search.png", confidence=0.7)
        pyautogui.click(camp_google)
        time.sleep(5)
        pyautogui.write("Italia")
        pyautogui.press('Enter')
        time.sleep(2)

def subscribe_mrbeast():
    # Așteptați câteva secunde pentru a se încărca pagina de rezultate Google
    time.sleep(5)
    # Deschideți YouTube într-o nouă fereastră
    keyboard.press_and_release('win+r')
    time.sleep(1)
    pyautogui.write('https://www.youtube.com/')
    keyboard.press_and_release('enter')
    time.sleep(5)
    # Găsiți și faceți clic pe caseta de căutare de pe YouTube
    if pyautogui.locateOnScreen(r"C:\Imagini\youtube.png", confidence=0.7) != None:
        youtube_search = pyautogui.locateOnScreen(r"C:\Imagini\youtube.png", confidence=0.7)
        pyautogui.click(youtube_search)
        time.sleep(1)
        # Căutați canalul MrBeast
        pyautogui.write("MrBeast")
        pyautogui.press('Enter')
        time.sleep(5)
        # Găsiți și faceți clic pe primul rezultat (canalul MrBeast)
        if pyautogui.locateOnScreen(r"C:\Imagini\MrBeast.png", confidence=0.7) != None:
            canal_mrbeast = pyautogui.locateOnScreen(r"C:\Imagini\MrBeast.png", confidence=0.7)
            pyautogui.click(canal_mrbeast)
            time.sleep(2)
            # Găsiți și faceți clic pe butonul "Subscribe"
            if pyautogui.locateOnScreen(r"C:\Imagini\Subscribe.png", confidence=0.7) != None:
                subscribe_button = pyautogui.locateOnScreen(r"C:\Imagini\Subscribe.png", confidence=0.7)
                pyautogui.click(subscribe_button)

response = pyautogui.confirm("Doriți să înceapă rularea programului", "Confirmare")
if response == "OK":
    cautare_google()
    subscribe_mrbeast()
else:
    pyautogui.alert("Ați ales Anulare", "Anulare")
