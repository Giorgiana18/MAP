zile_saptamana = ["Luni", "Marți", "Miercuri", "Joi", "Vineri", "Sâmbătă", "Duminică"]
x= int(input("Introduceți un număr de la 1 la 7: "))
if (1<=x<= 7):
    ziua = zile_saptamana[x-1]  
    print(f"Ziua corespunzătoare numărului {x} este {ziua}")
else:
    print("Numărul introdus nu este în intervalul corect (1-7).")