n=int(input("Introducem numarul n:"))
a=1
b=1
c=0
for i in range(1,n+1,1):
    print(a)
    c=a+b
    a=b
    b=c
    