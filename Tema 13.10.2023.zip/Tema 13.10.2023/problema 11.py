x=int(input("Introduceti de la tastatura numarul x:"))
if(x>-1):
    print("Numar pozitiv")
else:
    print("Numar negativ")