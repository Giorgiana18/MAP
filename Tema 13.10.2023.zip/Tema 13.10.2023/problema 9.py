an=int(input("Introduceti anul:"))
if (an % 4 == 0 and an % 100 != 0) or (an % 400 == 0):
    print(f"{an} este un an bisect.")
else:
    print(f"{an} nu este un an bisect.")