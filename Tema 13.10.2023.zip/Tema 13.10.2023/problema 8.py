a=int(input("Introduceti numarul a="))
if(a%2==0):
    print("Numarul este par")
else:
    print("Numarul este impar")
