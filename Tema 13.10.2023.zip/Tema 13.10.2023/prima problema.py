i=1
s=0
while i<=100:
  s=s+i
  i=i+1
print("suma numerelor de la 1 la 100:", s)