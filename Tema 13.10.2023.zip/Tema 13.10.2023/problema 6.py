n=int(input("Introduceti numarul n="))
numar_divizori=1
for d in range(1,n,1):
    if(n%d==0):
        numar_divizori=numar_divizori+1
if(numar_divizori==2):
     print("DA")
else:
    print("NU")

   