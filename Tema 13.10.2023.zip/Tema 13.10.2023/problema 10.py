x=int(input("Introduceti numarul x= "))
y=int(input("Introduceti numarul y= "))
s=0
s=x+y 
print("Suma lui x+y este:",s)