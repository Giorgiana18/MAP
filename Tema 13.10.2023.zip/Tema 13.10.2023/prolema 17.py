a = float(input("Introduceți măsura unghiului 1: "))
b = float(input("Introduceți măsura unghiului 2: "))
c = float(input("Introduceți măsura unghiului 3: "))
if a + b > c and a + c > b and b + c > a:
    print("Aceste măsuri pot reprezenta un triunghi.")
else:
    print("Aceste măsuri nu pot reprezenta un triunghi valid.")