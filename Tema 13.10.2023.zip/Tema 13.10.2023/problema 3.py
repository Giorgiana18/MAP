i=0
n=1
while(i<20):
    if(n%2!=0):
        print(n)
        i=i+1
    n=n+1