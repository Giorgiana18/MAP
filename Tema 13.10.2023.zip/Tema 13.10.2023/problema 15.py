vector=[]
for i in range(8):
    element=float(input(f"Introduceti elementul{i+1}:"))
    vector.append(element)
n=len(vector)
for i in range(n):
    for j in range(0,n-i-1):
        if vector[j]>vector[j+1]:
            vector[j], vector[j + 1] = vector[j + 1], vector[j]
print("Vectorul sortat folosind Bubble Sort:")
print(vector)