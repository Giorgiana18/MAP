v=[]
n=int(input("Introduceti numarul:"))
s=0
for i in range(0,n):
    a=int(input())
    v.append(a) 
for i in range(0,n):
    s=s+v[i]
print("Suma este:",s)
for i in range(0,n):
    media=s/n
print("Media este:",media)