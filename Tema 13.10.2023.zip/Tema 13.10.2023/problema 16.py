a = float(input("Introduceți coeficientul a: "))
b = float(input("Introduceți coeficientul b: "))
c = float(input("Introduceți coeficientul c: "))
D = b ** 2 - 4 * a * c
if D > 0:
    x1 = (-b + D ** 0.5) / (2 * a)
    x2 = (-b - D ** 0.5) / (2 * a)
    print(f"Ecuația are două soluții reale: x1 = {x1} și x2 = {x2}")
if D == 0:
    x = -b / (2*a)
    print(f"Ecuația are o soluție reală dublă: x = {x}")
if D < 0:
    parte_reala= -b / (2*a)
    parte_imaginara = (-D)**0.5 / (2*a)
    print(f"Ecuația nu are soluții reale. Soluțiile complexe sunt: x1 = {parte_reala} + {parte_imaginara}i și x2 = {parte_reala} - {parte_reala}i")