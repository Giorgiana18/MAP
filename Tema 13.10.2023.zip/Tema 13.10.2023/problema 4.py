a=int(input("Introduceti a:"))
b=int(input("Introduceti b:"))
while(a!=b):
    if(a>b):
        a=a-b
    else:
        b=b-a
print("CMMDC este:",a)