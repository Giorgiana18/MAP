p=1
for i in range(0,11):
    p=p*i
print("produsul primelor 10 numere naturale este:",p)
